﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ProjectAI;

namespace ProjectAI
{
    public class EnemyStats : ScriptableObject
    {
        [SerializeField]
        private float m_Health;

    }

}
