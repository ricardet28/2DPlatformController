﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ProjectAI;

namespace ProjectAI
{
    [CreateAssetMenu(menuName = "AI/Actions/Attack")]
    public class Attack : Action
    {
        public override void Act(FSMController fSM)
        {
            //Attack
        }
    }

}
